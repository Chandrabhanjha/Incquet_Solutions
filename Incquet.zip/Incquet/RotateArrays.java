public class RotateArray {
    public static void rotateArray(int[] array, int k) {
        int n = array.length;

        // Adjust k in case it's greater than n
        k = k % n;

        //  Reverse the whole array
        reverse(array, 0, n - 1);

        //  Reverse the first k elements
        reverse(array, 0, k - 1);

        // Reverse the rest of the elements
        reverse(array, k, n - 1);
    }

    
    private static void reverse(int[] array, int start, int end) {
        while (start < end) {
            int temp = array[start];
            array[start] = array[end];
            array[end] = temp;
            start++;
            end--;
        }
    }

    public static void main(String[] args) {
       
        int n = 7; // Size of the array
        int k = 3; // Steps to rotate
        int[] array = {1, 2, 3, 4, 5, 6, 7}; 

       
        System.out.println("Original Array:");
        printArray(array);

        
        rotateArray(array, k);

       
        System.out.println("Rotated Array:");
        printArray(array);
    }

    
    private static void printArray(int[] array) {
        for (int i : array) {
            System.out.print(i + " ");
        }
        System.out.println();
    }
}
