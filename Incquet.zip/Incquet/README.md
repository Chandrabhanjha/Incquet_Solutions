# Incquet_Solutions
Incquet Solutions Internship Assignment
