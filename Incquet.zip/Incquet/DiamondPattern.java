public class DiamondPattern {
    public static void printDiamond(int n) {
        if (n % 2 == 0) {
            System.out.println("Please enter an odd number.");
            return;
        }

int mid = n / 2;

// Upper half of the diamond, including the middle row
for (int i = 0; i <= mid; i++) {
printSpaces(mid - i);
printStars(2 * i + 1);
System.out.println();
}

        // Lower half of the diamond
        for (int i = mid - 1; i >= 0; i--) {
            printSpaces(mid - i);
            printStars(2 * i + 1);
            System.out.println();
        }
    }

    private static void printSpaces(int count) {
        for (int i = 0; i < count; i++) {
            System.out.print(" ");
        }
    }

    private static void printStars(int count) {
        for (int i = 0; i < count; i++) {
            System.out.print("* ");
        }
    }

    public static void main(String[] args) {
        int n = 5; // You can change this value to test with other odd numbers
        printDiamond(n);
    }
}
