document.addEventListener("DOMContentLoaded", () => {
const productTable = document.getElementById("productTable").getElementsByTagName("tbody")[0];
const addLineItemButton = document.getElementById("addLineItem");
const subtotalField = document.getElementById("subtotal");
const discountField = document.getElementById("discount");
const grandTotalField = document.getElementById("grandTotal");
const grandTotalUSDField = document.getElementById("grandTotalUSD");
const submitQuoteButton = document.getElementById("submitQuote");

// Set default date to today
document.getElementById("quoteDate").value = new Date().toISOString().split('T')[0];

// Event listeners
addLineItemButton.addEventListener("click", addLineItem);
discountField.addEventListener("input", updateTotals);
submitQuoteButton.addEventListener("click", submitQuote);

// Function to add a line item row
function addLineItem() {
const row = productTable.insertRow();

// Product Dropdown
const productCell = row.insertCell(0);
const productSelect = document.createElement("select");
productSelect.innerHTML = `<option value="Product1" data-price="50">Product 1</option>
<option value="Product2" data-price="100">Product 2</option>`;
productSelect.addEventListener("change", updateLineAmount);
productCell.appendChild(productSelect);

// Quantity Input
const quantityCell = row.insertCell(1);
const quantityInput = document.createElement("input");
quantityInput.type = "number";
quantityInput.value = 1;
quantityInput.addEventListener("input", updateLineAmount);
quantityCell.appendChild(quantityInput);

// Rate Input (auto-populated)
const rateCell = row.insertCell(2);
const rateInput = document.createElement("input");
rateInput.type = "number";
rateInput.value = productSelect.options[productSelect.selectedIndex].dataset.price;
rateInput.readOnly = true;
rateCell.appendChild(rateInput);

// Amount (auto-calculated)
const amountCell = row.insertCell(3);
const amountInput = document.createElement("input");
amountInput.type = "text";
amountInput.readOnly = true;
amountCell.appendChild(amountInput);

// Action Button to remove line item
const actionCell = row.insertCell(4);
const removeButton = document.createElement("button");
removeButton.textContent = "Remove";
removeButton.addEventListener("click", () => {
productTable.deleteRow(row.rowIndex - 1);
updateTotals();
});
actionCell.appendChild(removeButton);

updateLineAmount.call(row);  // Initial calculation for this line item
}

// Function to update line amount based on product and quantity
function updateLineAmount() {
const productSelect = this.cells[0].getElementsByTagName("select")[0];
const quantityInput = this.cells[1].getElementsByTagName("input")[0];
const rateInput = this.cells[2].getElementsByTagName("input")[0];
const amountInput = this.cells[3].getElementsByTagName("input")[0];

const rate = parseFloat(productSelect.options[productSelect.selectedIndex].dataset.price);
const quantity = parseFloat(quantityInput.value);
const amount = rate * quantity;

rateInput.value = rate;
amountInput.value = amount.toFixed(2);

updateTotals();
}

// Function to calculate subtotal, grand total and update fields
function updateTotals() {
let subtotal = 0;

for (let i = 0; i < productTable.rows.length; i++) {
const amount = parseFloat(productTable.rows[i].cells[3].getElementsByTagName("input")[0].value);
subtotal += isNaN(amount) ? 0 : amount;
}

const discount = parseFloat(discountField.value) || 0;
const grandTotal = subtotal - discount;

subtotalField.value = subtotal.toFixed(2);
grandTotalField.value = grandTotal.toFixed(2);
}

// Function to handle form submission and currency conversion
async function submitQuote(event) {
event.preventDefault();

// Convert grand total to USD
const grandTotal = parseFloat(grandTotalField.value);
const usdConversionRate = await fetch("https://open.er-api.com/v6/latest/USD")
.then(response => response.json())
.then(data => data.rates["INR"] || 1);

const grandTotalUSD = (grandTotal / usdConversionRate).toFixed(2);
grandTotalUSDField.value = grandTotalUSD;

alert("Form submitted successfully! Grand Total in USD: " + grandTotalUSD);

// /Redirect to Dashboard (for example)
window.location.href = "dashboard.html";
}
});
