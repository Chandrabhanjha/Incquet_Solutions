// Assuming the quote ID is passed when the page is loaded
const quoteId = 10006; // Placeholder for dynamically passed ID

// Sample data to simulate fetching data based on the Quote ID
const quoteData = {
    quoteDate: "March 27, 2022",
    status: "Draft",
    quoteId: "10006",
    customer: {
        name: "Test Company",
        address: "Spectrum Building, Powai, Mumbai",
        email: "test@testcompany.com"
    },
    items: [
        { productName: "Test Consultancy Services", qty: 1, rate: 999 },
        { productName: "Test Implementation Services", qty: 1, rate: 999 }
    ],
    discount: 199.80
};

// Function to calculate totals
function calculateTotals(items, discount) {
    const subtotal = items.reduce((sum, item) => sum + item.qty * item.rate, 0);
    const grandTotal = subtotal - discount;
    return { subtotal, grandTotal };
}

// Function to populate quote details on the page
function populateQuoteDetails(data) {
    // Left Card
    document.getElementById('quote-id').textContent = data.quoteId;
    document.getElementById('quote-status').textContent = data.status;

    // Right Card
    document.getElementById('customer-name').textContent = data.customer.name;
    document.getElementById('customer-address').textContent = data.customer.address;
    document.getElementById('customer-email').textContent = data.customer.email;

    // Items Section
    const itemsTable = document.getElementById('items-table');
    data.items.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.productName}</td>
            <td>${item.qty}</td>
            <td>$${item.rate.toFixed(2)}</td>
            <td>$${(item.qty * item.rate).toFixed(2)}</td>
        `;
        itemsTable.appendChild(row);
    });

    // Totals Section
    const totals = calculateTotals(data.items, data.discount);
    document.getElementById('subtotal').textContent = totals.subtotal.toFixed(2);
    document.getElementById('discount').textContent = data.discount.toFixed(2);
    document.getElementById('grand-total').textContent = totals.grandTotal.toFixed(2);
}

// Simulate fetching data and populate the page on load
document.addEventListener("DOMContentLoaded", function () {
    populateQuoteDetails(quoteData);
});
