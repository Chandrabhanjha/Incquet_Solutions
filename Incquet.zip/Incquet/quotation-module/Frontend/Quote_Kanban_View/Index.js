document.addEventListener("DOMContentLoaded", () => {
// Elements for each Kanban column
const draftColumn = document.getElementById("draft");
const sentColumn = document.getElementById("sent");
const acceptedColumn = document.getElementById("accepted");
const rejectedColumn = document.getElementById("rejected");
const sendQuoteButton = document.getElementById("send-quote-btn");

// Event listeners for Quote Cards and Send Quote button
draftColumn.addEventListener("click", handleQuoteClick);
sendQuoteButton.addEventListener("click", sendQuote);
acceptedColumn.addEventListener("click", handleAcceptReject);

// Handle opening Quote Detail Page when a quote card is clicked
function handleQuoteClick(event) {
if (event.target.classList.contains("quote-card")) {
const quoteId = event.target.getAttribute("data-quote-id");
openQuoteDetailPage(quoteId);
}
}

// Function to open the Quote Detail Page (assume it opens a new page)
function openQuoteDetailPage(quoteId) {
// Redirect to the Quote Detail Page (this would ideally be a real link)
alert(`Opening details for Quote ID: ${quoteId}`);
// window.location.href = `quoteDetail.html?quoteId=${quoteId}`;
}

// Send Quote function
async function sendQuote() {
const draftQuotes = draftColumn.getElementsByClassName("quote-card");
if (draftQuotes.length === 0) {
alert("No draft quotes available to send.");
return;
}

// Select the first draft quote for simplicity in this example
const quoteCard = draftQuotes[0];
const quoteId = quoteCard.getAttribute("data-quote-id");

try {
// Placeholder for sending email with quote data (replace with actual API call)
const emailSent = await sendEmail(quoteId);
if (emailSent) {
sentColumn.appendChild(quoteCard); // Move quote to Sent status
quoteCard.classList.remove("quote-card"); // Update the status
alert(`Quote ID: ${quoteId} sent successfully!`);
}
} catch (error) {
console.error("Error sending email:", error);
alert("Failed to send quote. Please try again.");
}
}

// Placeholder for email sending function using mock API call
async function sendEmail(quoteId) {
// Mock email send (replace with actual email API like SendGrid or Mailgun)
const response = await fetch("https://api.example.com/send-email", {
method: "POST",
headers: { "Content-Type": "application/json" },
body: JSON.stringify({ quoteId: quoteId })
});
return response.ok;
}

// Accept/Reject Button functionality for Sent quotes
function handleAcceptReject(event) {
const button = event.target;
const quoteCard = button.closest(".quote-card");

if (button.classList.contains("accept-btn")) {
acceptedColumn.appendChild(quoteCard);
alert(`Quote ID: ${quoteCard.getAttribute("data-quote-id")} accepted!`);
} else if (button.classList.contains("reject-btn")) {
rejectedColumn.appendChild(quoteCard);
alert(`Quote ID: ${quoteCard.getAttribute("data-quote-id")} rejected!`);
}
}
});
